Welcome to Fasteners's documentation!
=====================================

A python `package`_ that provides useful locks.

*Contents:*

.. toctree::
   :maxdepth: 3

   api/lock
   api/process_lock

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _package: https://pypi.python.org/pypi/fasteners

